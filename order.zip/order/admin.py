from django.contrib import admin
from .models import Order

admin.site.register(Order)
# admin.site.register(PickOrder)
# admin.site.register(PackOrder)
# admin.site.register(Delivery)
# admin.site.register(Invoice)
